self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6cb2f86953091fa9e0b98f24634db926",
    "url": "./index.html"
  },
  {
    "revision": "0b9c2782b778df68753d",
    "url": "./static/js/2.bb009799.chunk.js"
  },
  {
    "revision": "79b13e5621aab7d76db008fe544bc508",
    "url": "./static/js/2.bb009799.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a943e6b16204b37f2878",
    "url": "./static/js/main.134afe35.chunk.js"
  },
  {
    "revision": "f3f47d4bcf96ea8798b8",
    "url": "./static/js/runtime-main.e84bfa8e.js"
  }
]);