self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a89ea4b4301764044ddab49ce346d194",
    "url": "./index.html"
  },
  {
    "revision": "0b9c2782b778df68753d",
    "url": "./static/js/2.bb009799.chunk.js"
  },
  {
    "revision": "79b13e5621aab7d76db008fe544bc508",
    "url": "./static/js/2.bb009799.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5c07c1f15035f1211594",
    "url": "./static/js/main.c4459c1d.chunk.js"
  },
  {
    "revision": "f3f47d4bcf96ea8798b8",
    "url": "./static/js/runtime-main.e84bfa8e.js"
  }
]);