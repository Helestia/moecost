self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cfb84ca5c1052f57c6e5e04de9976f39",
    "url": "./index.html"
  },
  {
    "revision": "0b9c2782b778df68753d",
    "url": "./static/js/2.bb009799.chunk.js"
  },
  {
    "revision": "79b13e5621aab7d76db008fe544bc508",
    "url": "./static/js/2.bb009799.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ab9d382fea9e314c5e27",
    "url": "./static/js/main.6961a04d.chunk.js"
  },
  {
    "revision": "f3f47d4bcf96ea8798b8",
    "url": "./static/js/runtime-main.e84bfa8e.js"
  }
]);